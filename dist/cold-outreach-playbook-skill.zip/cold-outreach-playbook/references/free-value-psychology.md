# The Psychology of Free Value: Why Gifts Grab Attention

The playbook's engine — enormous free value in the first touch — works because it sits on well-studied psychological mechanisms. Knowing the mechanisms lets you design gifts and messages that use them deliberately instead of by luck. Apply these when building the gift (Part 1), the message (Part 3), and the copy. One or two per message: stacking every technique into one email reads as manipulation, and readers smell it.

## 1. Reciprocity — and its three amplifiers

The foundation (Regan's classic experiment: an unrequested soda doubled later compliance; Cialdini's first principle). People are wired to balance the scales with whoever gives first. But the famous waiter–mint studies show *how* you give matters as much as *what*:

- **Unexpected beats expected.** A second mint delivered as a surprise raised tips far more than two mints given routinely. Application: the gift the prospect never asked for (the teardown already recorded, the analysis already run) out-pulls the gated download they've seen everywhere.
- **Personalized beats generic.** "For you specifically" — the delivery framing alone lifted tips ~23%. Application: the copy must make clear this was made for THEM, not a blast: "I ran the numbers for YOUR three locations," never "we made a guide for practices like yours."
- **Given-first beats promised.** Reciprocity fires on receipt, not on offer. This is the psychological basis of the immediacy rule (Part 2.5): deliver in the message, don't tease.

**Guardrail:** reciprocity is a trust mechanic, not a lever. The gift must be genuinely valuable with no hidden hook — a "free audit" that's secretly a pitch deck burns the mechanism and the sender's name with it.

## 2. The zero-price effect — free is a category, not a price

Ariely's chocolate experiments: cutting a price from 1¢ to 0¢ nearly quadrupled demand, far beyond what any 1¢ discount should do. "Free" switches people out of cost-benefit math entirely — benefits get magnified, downsides ignored.

**Application:** say the word free plainly, and pair it with a **value anchor** so free reads as "mispriced," not "worthless": "agencies charge $400 for this exact audit — yours free, no strings." The anchor is what turns the zero-price effect from suspicious to irresistible.

## 3. The labor illusion — show the work

Buell & Norton: people value the identical output more when they can see the effort behind it — and perceived effort itself triggers reciprocity. A search that visibly "works" for 30 seconds is preferred to an instant one with the same results.

**Application:** one sentence of visible work in message 1: "I went through your booking flow on mobile, timed all 11 steps, and compared it against 12 other Austin clinics." A personal video walking through THEIR site is the maximum-strength version — the effort is undeniable because they can watch it. This is also why hand-made gifts punch above their scalability score.

## 4. The information gap — engineered curiosity that closes

Loewenstein: curiosity ignites when attention lands on a specific gap between what someone knows and wants to know — strongest when the gap is **specific, salient, personally meaningful, and closable**. "3 things on your website are costing you bookings" opens a gap that is numbered (specific), about them (meaningful), and answered one click away (closable).

**Application:** open gaps about THEIR business, never generic ones; always close the gap you open — inside the message or one click deep. A gap that never closes is clickbait, and it spends trust you don't have yet.

## 5. Endowment framing — make it already theirs

People value what they own more than what they might get, and something made *about them* is psychologically already theirs. "Your report is ready" lands differently than "want a report?" — declining now means losing *their* report, which loss aversion makes uncomfortable.

**Application:** name the asset possessively ("your teardown," "your benchmark position: 14th of 20") and build it before asking anything. Loss-framed implications ("this is costing you ~$900/month") grab harder than gain framing of the same number — use the loss frame in the implication beat, and keep the number defensible.

## 6. "But you are free" — affirm the exit

A meta-analysis across dozens of studies (Carpenter) found that explicitly affirming someone's freedom to refuse measurably increases compliance (medium effect; strongest when the response is immediate — treat it as a useful edge, not a magic trick). For cold outreach it does double duty: it also disarms the skepticism filter, because spammers never say "feel free to ignore this."

**Application:** one honest exit line near the micro-ask: "No strings — it's yours either way," "Totally fine to ignore this," "Keep it even if we never talk." Never fake urgency in the same message; urgency and freedom-affirmation cancel each other.

## 7. The contribution ask — the Franklin effect and co-creation

Asking someone for a *small, flattering* contribution makes them invest in you — people like those they've helped (the Franklin effect), and they overvalue what they helped build (co-creation). This is the psychology behind the give-them-a-stage plays (Part 4): "want your quote in the report?" is simultaneously a gift (status) and an investment (theirs now — they'll share it when it ships).

**Application:** when a stage play is running, the micro-ask can be a contribution ask. Keep it small and flattering; asking them to do real work before receiving value is a rejection-rule violation.

## 8. Scarcity and FOMO — the fear of the closing door

Worchel's cookie-jar experiment: identical cookies were rated more desirable from the nearly-empty jar — and *most* desirable when the scarcity had a stated social reason ("demand reduced the supply") rather than looking accidental. Cialdini codified it: restricted availability inflates perceived value, and fear of missing out overrides slow rational evaluation. Social proof compounds it — scarcity plus "your peers are already in" is the strongest tension combination there is.

**Application (Part 4, family 7):** competitor motion, peer-benchmark gaps, left-out-of-the-report, closing windows, honest capacity limits — always with the real reason stated ("I do three of these a week by hand"), because scarcity-with-a-reason is both more effective and true. **The hard line:** artificial scarcity is detectable and, once detected, destroys everything the gift built. No fake countdowns, no invented slots, no "spots filling fast" that aren't. If the constraint isn't real, use a different family.

## 9. Self-reference — the cocktail-party effect in an inbox

The brain grants pre-attentive priority to self-relevant signals: roughly a third of people hear their own name even in a conversation they're actively ignoring, and self-referenced information is remembered better than anything else. An inbox is a noisy party; their name, their company's name, their own words are the signals that cut through it.

**Application:** the prospect's company name or their own quoted phrase in the subject line and first sentence — "found 3 things on {{clinic_name}}'s site," "your line about 'chart-chasing' stuck with me." This is why the Part 0 research captures their exact words: self-reference isn't `Hi {{first_name}}` (everyone does that; it's wallpaper now) — it's their *world* reflected back accurately.

## 10. The "because" effect — every ask carries a reason

Langer's copy-machine study: adding a reason to a small request raised compliance from 60% to ~94% — and for small asks, even a circular reason worked, because "because" itself signals justification. For larger asks, only real reasons moved people.

**Application:** the micro-ask is a small ask, so it always travels with its reason — and the best reason is the trigger itself: "Worth a look? — asking because you're clearly redoing the funnel this quarter." Never use an empty reason: the real trigger is sitting right there in the message, so the honest "because" is also the strongest one.

## 11. Unity and the shared enemy — Cialdini's seventh principle

Unity goes beyond liking or similarity: it's shared *identity* — "one of us." Tajfel's minimal-group experiments showed how little it takes to create in-group loyalty, and nothing activates a tribe faster than its common adversary. In-group messages get processed faster, trusted more, and defended.

**Application (Part 4, family 8):** genuine shared membership, insider language from the research, the shared enemy the ICP already resents (the roll-ups, the platform fees, the algorithm), identity labels they'd be proud to accept. **The line:** membership claims must be true, and enemies must be systems, not people. Faking belonging is impersonation, and it reads that way the moment they probe.

## 12. Open loops — the Zeigarnik effect across the sequence

Unfinished things occupy the mind: interrupted tasks are remembered roughly twice as well as completed ones. A sequence is a chain of open-and-close: each touch closes the last loop and honestly opens the next.

**Application:** use loops across the *sequence*, not to gate the first gift (the immediacy rule wins every conflict): message 1 delivers the finding AND mentions what the full teardown covers; message 2 delivers the teardown and notes the benchmark table exists; message 3 delivers the table. Every loop opened must close in the next touch — an open loop that never closes is a broken promise with a psychology citation.

## Mapping techniques to the four beats

| Beat | Techniques that live there |
|---|---|
| Trigger | Personalization amplifier (this is about YOU), information gap (opened) |
| Implication | Loss framing, labor illusion (the analysis shows the work), gap partially closed |
| Asset | Reciprocity (delivered, not promised), zero-price + value anchor, endowment naming, labor illusion |
| Micro-ask | But-you-are-free line, contribution ask (stage plays), zero pressure |
| Any beat, honest only | Scarcity with its reason stated, peer social proof, FOMO (family 7) |
| Subject + first line | Self-reference (their name, their company, their words) |
| Micro-ask, again | The "because" reason (the trigger doubles as the reason) |
| Across the sequence | Open loops that always close in the next touch |
| Whole-message frame | Unity / shared enemy / identity labels (family 8, true only) |

## The line not to cross

Every mechanism above works because it rides on something true: real effort, real value, real freedom to walk away. Used to dress up an empty message, the same mechanisms backfire into the one outcome cold outreach can't recover from — being recognized as a manipulation. The White et al. finding on over-personalization applies to all of it: value must feel proportionate and professional, or the reaction is reactance, not reciprocity. When in doubt, give more and engineer less.

## Sources

- Regan (1971), reciprocity compliance experiment; Cialdini, *Influence* — [overview](https://www.cognitigence.com/blog/principle-of-reciprocity-norm)
- Strohmetz et al., the waiter–mint studies (unexpected + personalized delivery) — [summary](https://www.influenceatwork.com/7-principles-of-persuasion/)
- Shampanier, Mazar & Ariely (2007), *Zero as a Special Price* — [paper](https://web.mit.edu/ariely/www/MIT/Papers/zero.pdf)
- Buell & Norton (2011), *The Labor Illusion* — [paper](https://www.hbs.edu/ris/Publication%20Files/Norton_Michael_The%20labor%20illusion%20How%20operational_f4269b70-3732-4fc4-8113-72d0c47533e0.pdf)
- Loewenstein (1994), information-gap theory of curiosity — [overview](https://psychologyfanatic.com/information-gap-theory/); Golman & Loewenstein — [paper](https://www.cmu.edu/dietrich/sds/docs/golman/golman_loewenstein_curiosity.pdf)
- Carpenter (2013), BYAF meta-analysis — [abstract](https://www.tandfonline.com/doi/full/10.1080/10510974.2012.727941); later re-examination with reproducibility caveats — [meta-psychology](https://open.lnu.se/index.php/metapsychology/article/view/2640/3402)
- White et al. (2008), reactance to over-personalization — cited in the agent operating playbook's guardrails
- Worchel, Lee & Adewole (1975), the cookie-jar scarcity experiment; Cialdini's scarcity principle — [overview](https://www.explorepsychology.com/scarcity-principle/), [scarcity psychology](https://www.coglode.com/nuggets/scarcity)
- Langer, Blank & Chanowitz (1978), the copy-machine "because" study — [summary](https://jamesclear.com/copy-machine-study)
- The cocktail-party effect and own-name attention — [overview](https://en.wikipedia.org/wiki/Cocktail_party_effect); self-reference effect in marketing — [overview](https://www.choicehacking.com/2020/08/14/self-reference-effect/)
- Cialdini's seventh principle, Unity — [overview](https://cxl.com/blog/cialdini-unity/); Tajfel's minimal-group experiments (in-group formation)
- Zeigarnik effect (unfinished-task memory) — [overview](https://en.wikipedia.org/wiki/Zeigarnik_effect)
